<?php require_once('../private/initialize.php');//bring in code from initialize.php ?>

<?php include(SHARED_PATH . '/public_header.php');//path to public header in shared folder ?>

<div id="main">
<?php include(SHARED_PATH . '/public_navigation.php');//path to public navigation in the shared folder ?>
  <div id="page">

  </div>

</div>

<?php include(SHARED_PATH . '/public_footer.php');//path to public footer in shared folder ?>
